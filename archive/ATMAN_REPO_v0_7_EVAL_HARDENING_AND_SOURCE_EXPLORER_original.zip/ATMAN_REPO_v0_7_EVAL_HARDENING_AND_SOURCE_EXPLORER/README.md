# Atman Repo v0.7 — Eval Hardening and Source Explorer

Atman is a Hindi-first, source-governed Dharma AI platform. v0.7 upgrades v0.6 with hardened NyayaBench evaluation gates and public/admin source explorer APIs.

## Run

```bash
cp .env.example .env
docker compose up --build
```

## URLs

```text
API:        http://localhost:8000/docs
Studio:     http://localhost:3000
Public App: http://localhost:3001
Qdrant:     http://localhost:6333/dashboard
MinIO:      http://localhost:9001
```

## New in v0.7

```text
POST /eval/run/hardened
GET  /eval/runs/{run_id}/results
POST /eval/citation/check
POST /eval/fake-shloka/check
GET  /public/source-explorer/search
GET  /public/source-explorer/sources/{source_id}
GET  /source-explorer/search
GET  /source-explorer/sources/{source_id}
```

## Boundary

This repo is runnable, but it still does not bundle Qwen weights or a production-reviewed Dharma corpus.
