export function Nav() {
  return (
    <nav className="nav">
      <a href="/">Dashboard</a>
      <a href="/sources">Sources</a>
      <a href="/rag">RAG Debugger</a>
      <a href="/content">Content Factory</a>
      <a href="/review">Review Queue</a>
      <a href="/exports">Exports</a>
      <a href="/eval">NyayaBench</a>
    </nav>
  );
}
