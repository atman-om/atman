'use client';
import { useState } from 'react';
import { Nav } from '../../components/Nav';
import { apiJson } from '../../lib/api';

export default function EvalPage() {
  const [result, setResult] = useState<unknown>(null);
  async function run() {
    const data = await apiJson('/eval/run', { method: 'POST', body: JSON.stringify({ benchmark_name: 'nyayabench_seed', model_version: 'Atman-Lab-Qwen-14B-v0.1' }) });
    setResult(data);
  }
  return (
    <main className="shell">
      <Nav />
      <h1>NyayaBench Seed Runner</h1>
      <button onClick={run}>Run Seed Eval</button>
      {result && <pre>{JSON.stringify(result, null, 2)}</pre>}
    </main>
  );
}
