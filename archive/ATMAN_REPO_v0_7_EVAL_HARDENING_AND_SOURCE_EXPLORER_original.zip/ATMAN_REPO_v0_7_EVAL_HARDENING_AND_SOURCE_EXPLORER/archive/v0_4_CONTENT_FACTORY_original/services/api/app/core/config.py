from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="ATMAN_", extra="ignore")

    env: str = "local"
    log_level: str = "INFO"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    database_url: str = "sqlite+aiosqlite:///./atman.db"
    sync_database_url: str = "sqlite:///./atman.db"
    redis_url: str = "redis://localhost:6379/0"
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection: str = "atman_chunks"
    object_store_endpoint: str = "http://localhost:9000"
    object_store_bucket: str = "atman-corpus"
    object_store_access_key: str = "atman"
    object_store_secret_key: str = "atman-secret"
    jwt_secret: str = "change-me-in-production"
    cors_origins: str = "http://localhost:3000"
    model_family: str = "Qwen"
    runtime_model: str = "Atman-Lab-Qwen-14B"
    content_model: str = "Atman-Lab-Qwen-14B"
    embedding_dim: int = Field(default=384, ge=32, le=4096)
    llm_base_url: str | None = None
    llm_api_key: str | None = None
    enable_network_crawl: bool = False
    content_export_dir: str = "./generated/exports"
    content_max_batch_items: int = Field(default=250, ge=1, le=5000)
    content_min_source_coverage: float = Field(default=0.60, ge=0.0, le=1.0)

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
