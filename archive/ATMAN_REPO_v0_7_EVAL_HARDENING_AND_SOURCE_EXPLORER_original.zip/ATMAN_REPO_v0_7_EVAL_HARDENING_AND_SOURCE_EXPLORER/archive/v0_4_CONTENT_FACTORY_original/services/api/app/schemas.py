from __future__ import annotations
from typing import Any, Literal
from pydantic import BaseModel, Field, HttpUrl

from services.api.app.domain.enums import (
    ArtifactType,
    ContentBatchStatus,
    ContentReviewStatus,
    ExportFormat,
    RightsStatus,
)


class SourceCreate(BaseModel):
    source_type: str = Field(min_length=2, max_length=64)
    title: str = Field(min_length=1, max_length=512)
    language: str | None = Field(default="hi", max_length=32)
    tradition_scope: list[str] = Field(default_factory=list)
    rights_status: RightsStatus = RightsStatus.UNKNOWN
    source_metadata: dict[str, Any] = Field(default_factory=dict)
    text: str | None = Field(default=None, description="Optional plaintext to ingest immediately")


class SourceOut(BaseModel):
    id: str
    source_type: str
    title: str
    language: str | None
    tradition_scope: list[str]
    rights_status: str
    ingestion_status: str
    checksum_sha256: str | None
    source_metadata: dict[str, Any]

    model_config = {"from_attributes": True}


class SourceDecision(BaseModel):
    decision: Literal[
        "reject",
        "needs_cleanup",
        "promote_z0_to_z1",
        "promote_z1_to_z2",
        "mark_reference_only",
        "mark_rights_red",
    ]
    reviewer_id: str | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)


class ChunkOut(BaseModel):
    id: str
    source_id: str
    chunk_text: str
    token_count: int
    chunk_order: int
    citation_locator: dict[str, Any]
    quality_score: float
    review_status: str

    model_config = {"from_attributes": True}


class RagQueryRequest(BaseModel):
    question: str = Field(min_length=2, max_length=4000)
    language: str = Field(default="hi", max_length=16)
    top_k: int = Field(default=5, ge=1, le=20)
    require_citations: bool = True


class Citation(BaseModel):
    chunk_id: str
    source_id: str
    title: str
    locator: dict[str, Any]
    score: float
    text_preview: str


class SafetyReport(BaseModel):
    allowed: bool
    flags: list[str] = Field(default_factory=list)
    reason: str | None = None


class RagQueryResponse(BaseModel):
    query_id: str | None = None
    answer: str
    citations: list[Citation]
    safety_report: SafetyReport
    model_name: str
    latency_ms: int


ContentTypeLiteral = Literal[
    "notes",
    "qa",
    "mcq",
    "flashcards",
    "explainer",
    "lesson_plan",
    "article",
    "daily_wisdom",
    "worksheet",
    "shorts_script",
    "social_post",
]


class ContentGenerateRequest(BaseModel):
    content_type: ContentTypeLiteral
    topic: str = Field(min_length=2, max_length=512)
    language: str = Field(default="hi", max_length=16)
    difficulty: Literal["basic", "intermediate", "advanced"] = "intermediate"
    quantity: int = Field(default=5, ge=1, le=100)
    source_required: bool = True
    template_id: str | None = None
    generation_config: dict[str, Any] = Field(default_factory=dict)


class ContentTemplateCreate(BaseModel):
    name: str = Field(min_length=2, max_length=128)
    content_type: ContentTypeLiteral
    language: str = "hi"
    prompt_template: str = Field(min_length=10)
    output_schema: dict[str, Any] = Field(default_factory=dict)
    version: str = "0.4.0"
    active: bool = True


class ContentTemplateOut(BaseModel):
    id: str | None = None
    name: str
    content_type: str
    language: str
    prompt_template: str
    output_schema: dict[str, Any]
    version: str
    active: bool

    model_config = {"from_attributes": True}


class ContentBatchCreate(BaseModel):
    name: str = Field(min_length=2, max_length=256)
    content_type: ContentTypeLiteral
    topic: str = Field(min_length=2, max_length=512)
    language: str = "hi"
    difficulty: Literal["basic", "intermediate", "advanced"] = "intermediate"
    quantity: int = Field(default=10, ge=1, le=5000)
    template_id: str | None = None
    source_required: bool = True
    generation_config: dict[str, Any] = Field(default_factory=dict)
    created_by: str | None = None


class ContentBatchOut(BaseModel):
    id: str
    name: str
    content_type: str
    topic: str
    language: str
    difficulty: str
    quantity: int
    template_id: str | None
    status: str
    generation_config: dict[str, Any]
    metrics: dict[str, Any]

    model_config = {"from_attributes": True}


class ContentItemOut(BaseModel):
    id: str
    batch_id: str | None = None
    template_id: str | None = None
    item_index: int = 0
    title: str | None = None
    content_type: str
    topic: str
    language: str
    body: str
    source_chunk_ids: list[str]
    quality_report: dict[str, Any]
    review_status: str
    export_status: str = "NOT_EXPORTED"
    version: int = 1
    provenance: dict[str, Any] = Field(default_factory=dict)

    model_config = {"from_attributes": True}


class ContentReviewDecision(BaseModel):
    decision: ContentReviewStatus
    reviewer_id: str | None = None
    reason: str | None = None
    checklist: dict[str, Any] = Field(default_factory=dict)


class ContentReviewEventOut(BaseModel):
    id: str
    item_id: str
    reviewer_id: str | None
    decision: str
    reason: str | None
    checklist: dict[str, Any]

    model_config = {"from_attributes": True}


class ContentExportRequest(BaseModel):
    export_format: ExportFormat = ExportFormat.JSONL
    batch_id: str | None = None
    review_status: ContentReviewStatus | None = ContentReviewStatus.APPROVED
    include_manifest: bool = True


class ContentExportOut(BaseModel):
    id: str
    batch_id: str | None
    export_format: str
    file_path: str
    item_count: int
    manifest: dict[str, Any]

    model_config = {"from_attributes": True}


class EvalRunRequest(BaseModel):
    benchmark_name: str = "nyayabench_seed"
    model_version: str = "Atman-Lab-Qwen-14B-v0.1"


class EvalRunOut(BaseModel):
    id: str
    model_version: str
    benchmark_name: str
    score: dict[str, Any]
    hard_failures: list[dict[str, Any]]
    approved: bool

    model_config = {"from_attributes": True}


class ReleaseGateRequest(BaseModel):
    artifact_type: ArtifactType
    artifact_version: str
    metrics: dict[str, Any]
    hard_failures: list[dict[str, Any]] = Field(default_factory=list)
    required_approvals: list[str] = Field(default_factory=list)


class ReleaseGateOut(BaseModel):
    id: str
    artifact_type: str
    artifact_version: str
    allowed: bool
    metrics: dict[str, Any]
    hard_failures: list[dict[str, Any]]
    required_approvals: list[str]

    model_config = {"from_attributes": True}


class WebSourceRequest(BaseModel):
    url: HttpUrl
    rights_status: RightsStatus = RightsStatus.UNKNOWN
    fetch_now: bool = False


class WebSourceOut(BaseModel):
    id: str
    url: str
    title: str | None
    robots_status: str
    tos_status: str
    rights_status: str
    content_hash: str | None
    quality_score: float
    provenance: dict[str, Any]

    model_config = {"from_attributes": True}
