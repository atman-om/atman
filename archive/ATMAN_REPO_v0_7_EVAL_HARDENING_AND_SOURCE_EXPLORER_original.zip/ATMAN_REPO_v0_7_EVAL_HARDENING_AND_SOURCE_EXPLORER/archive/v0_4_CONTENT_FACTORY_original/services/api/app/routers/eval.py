from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from services.api.app.core.db import get_session
from services.api.app.schemas import EvalRunRequest, EvalRunOut
from services.api.app.services.eval_runner import run_seed_eval

router = APIRouter(prefix="/eval", tags=["eval"])


@router.post("/run", response_model=EvalRunOut)
async def run_eval(payload: EvalRunRequest, session: AsyncSession = Depends(get_session)) -> EvalRunOut:
    run = await run_seed_eval(
        session,
        model_version=payload.model_version,
        benchmark_name=payload.benchmark_name,
    )
    return EvalRunOut.model_validate(run)
