from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from services.api.app.core.config import get_settings
from services.api.app.routers import content, eval, health, rag, release, sources, web

settings = get_settings()

app = FastAPI(
    title="Atman Platform API",
    version="0.4.0",
    description="Hindi-first, source-governed Dharma AI platform with governed content factory.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(sources.router)
app.include_router(rag.router)
app.include_router(content.router)
app.include_router(eval.router)
app.include_router(release.router)
app.include_router(web.router)
