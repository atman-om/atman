from collections.abc import AsyncGenerator
from services.api.app.core.config import Settings, get_settings
from services.api.app.services.vector_store import QdrantStore


def get_vector_store() -> QdrantStore | None:
    settings = get_settings()
    if not settings.qdrant_url:
        return None
    return QdrantStore(
        url=settings.qdrant_url,
        collection=settings.qdrant_collection,
        dim=settings.embedding_dim,
    )
