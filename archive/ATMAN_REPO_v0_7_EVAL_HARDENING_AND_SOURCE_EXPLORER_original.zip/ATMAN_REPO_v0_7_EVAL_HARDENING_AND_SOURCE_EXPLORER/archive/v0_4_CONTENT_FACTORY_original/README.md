# Atman Repo v0.4 — Content Factory

**Atman Repo v0.4 Content Factory** extends the runnable v0.3 platform into a governed, batch-oriented content-generation system for Hindi-first, source-governed Dharma learning material.

## What v0.4 adds

- Batch content-generation jobs with status tracking.
- Template registry for notes, Q&A, MCQ, flashcards, lesson plans, explainers, articles, daily wisdom, worksheet, and short-video scripts.
- Source-grounded generation using the existing RAG retrieval layer.
- Quality scoring with citation coverage, safety flags, source coverage, review routing, and provenance metadata.
- Human-in-loop review workflow for approve/reject/revise decisions.
- Export artifacts in JSONL, Markdown, and CSV.
- Atman Studio pages for batch generation, review queue, and exports.
- Additional JSON schemas, prompt files, fixtures, scripts, migrations, and tests.

## Boundary

v0.4 is still **model-service-ready**, not Qwen-weight-bundled. It uses deterministic local generation and retrieval-safe templates so the platform runs without downloading model weights. Production Qwen runtime integration remains the next major step.

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:

- API: http://localhost:8000/docs
- Studio: http://localhost:3000
- Qdrant: http://localhost:6333/dashboard
- MinIO: http://localhost:9001

## Fast local smoke test

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
pytest
uvicorn services.api.app.main:app --reload
```

## Content Factory flow

```text
seed/review sources
→ retrieve source chunks
→ render governed content templates
→ score quality + provenance
→ review queue
→ approve/reject/revise
→ export JSONL/Markdown/CSV
```

## Canonical lock

```text
Base family: Qwen
Runtime track: Atman-Lab-Qwen-14B
Content Factory track: Atman-Lab-Qwen-32B optional, 14B default
Production: Atman-Prod only after NyayaBench + release gate
```
