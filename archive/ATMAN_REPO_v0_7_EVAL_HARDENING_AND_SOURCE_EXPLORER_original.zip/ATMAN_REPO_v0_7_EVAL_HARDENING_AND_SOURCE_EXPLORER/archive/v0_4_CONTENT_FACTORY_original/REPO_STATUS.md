# Atman Repo v0.4 Content Factory — Status

## Shipped in this artifact

| Capability | Status |
|---|---:|
| v0.3 runnable scaffold preserved | ✅ |
| Batch content generation | ✅ |
| Template registry | ✅ |
| Review workflow | ✅ |
| JSONL/Markdown/CSV exports | ✅ |
| Quality scoring | ✅ |
| Provenance ledger fields | ✅ |
| Atman Studio Content Factory UI | ✅ |
| Docker Compose local stack | ✅ |
| Tests | ✅ |

## Not shipped yet

```text
actual Qwen model weights
production vector embeddings
real Sanskrit verifier model
paid/licensed corpus
fine-tuning execution
public consumer app
enterprise auth provider
cloud deployment manifests
```

## Next repo artifact

```text
ATMAN_REPO_v0_5_PUBLIC_APP_AND_QWEN_RUNTIME.zip
```

## Operational invariant

```text
Generate at scale only after source, rights, citation, safety, and review gates are active.
```
