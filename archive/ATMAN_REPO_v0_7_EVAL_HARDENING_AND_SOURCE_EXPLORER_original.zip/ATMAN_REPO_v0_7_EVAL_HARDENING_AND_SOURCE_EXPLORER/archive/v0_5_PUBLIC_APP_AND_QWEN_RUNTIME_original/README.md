# Atman Repo v0.5 — Public App and Qwen Runtime

**Atman Repo v0.5** upgrades the governed v0.4 content factory into a public-app-ready platform with a Qwen runtime abstraction.

## What v0.5 adds

- Public Next.js app at `apps/public`.
- Public routes: `/`, `/ask`, `/sources`, `/shloka`.
- Public API endpoints under `/public`.
- Qwen runtime facade under `/runtime`.
- Deterministic fallback mode for local/offline execution.
- OpenAI-compatible Qwen serving mode for vLLM/Ollama/LM Studio/TGI.
- Streaming `/public/ask/stream` scaffold.
- Qwen RAG prompt pack.
- Runtime runbook, route map, OpenAPI incremental schema, scripts, tests.
- Original v0.4 repo archived under `archive/v0_4_CONTENT_FACTORY_original/`.

## Boundary

This repo does **not** bundle Qwen model weights. It is runtime-ready.

Default local mode is deterministic:

```bash
ATMAN_QWEN_RUNTIME_MODE=deterministic
```

For real Qwen serving:

```bash
ATMAN_QWEN_RUNTIME_MODE=openai_compatible
ATMAN_QWEN_MODEL_ID=Qwen/Qwen3-14B
ATMAN_QWEN_BASE_URL=http://your-qwen-server:8001
```

The server must expose `/v1/chat/completions`.

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:

- API: http://localhost:8000/docs
- Public app: http://localhost:3001
- Studio: http://localhost:3000
- Qdrant: http://localhost:6333/dashboard
- MinIO: http://localhost:9001

## Fast local smoke test

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[dev]"
pytest
python scripts/check_qwen_runtime.py
uvicorn services.api.app.main:app --reload
```

## Canonical lock

```text
Base family: Qwen
Runtime track: Atman-Lab-Qwen-14B-v0.5
Content track: Atman-Lab-Qwen-14B-v0.5
Production name: Atman-Prod only after NyayaBench + release gate
```
