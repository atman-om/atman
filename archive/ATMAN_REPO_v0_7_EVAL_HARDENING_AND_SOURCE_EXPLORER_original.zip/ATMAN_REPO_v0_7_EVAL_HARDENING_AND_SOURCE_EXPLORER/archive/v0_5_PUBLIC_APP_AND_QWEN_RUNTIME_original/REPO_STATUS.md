# Repo Status — v0.5

| Layer | Status |
|---|---:|
| v0.4 content factory preserved | ✅ |
| Public app shell | ✅ |
| Public ask API | ✅ |
| Public source explorer API | ✅ |
| Qwen runtime facade | ✅ |
| Deterministic fallback runtime | ✅ |
| OpenAI-compatible Qwen integration | ✅ |
| Streaming ask scaffold | ✅ |
| Actual Qwen weights bundled | ❌ |
| Production auth/payment/user accounts | ❌ |
| Full public shloka explainer endpoint | ❌ |
| Production corpus | ❌ |
| Atman-Prod release | ❌ |

## Next artifact

`ATMAN_REPO_v0_6_CORPUS_INGESTION_AND_REVIEW.zip`

Focus:

- PDF upload + OCR worker
- EPUB/TXT/HTML ingestion
- source locator parser
- source/chunk review UI hardening
- rights evidence templates
- corpus promotion to Z2
