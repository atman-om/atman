# Repo Status — v0.7

## Implemented

- v0.6 corpus ingestion and review preserved.
- Hardened NyayaBench eval run endpoint.
- Eval case/result persistence schema.
- Citation alignment checker.
- Fake-shloka risk checker.
- Public and admin source explorer APIs.
- Public Source Explorer UI.
- Studio NyayaBench dashboard upgraded.
- New migration `0005_eval_hardening_source_explorer.py`.
- v0.7 tests and schemas.

## Not included

- Qwen weights.
- Production corpus.
- Human theological review panel tooling.
- LLM-judge ensemble grading.
